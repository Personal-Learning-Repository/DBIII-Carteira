package br.edu.unisep.carteira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarteiraApplicationTests {

    @Test
    void contextLoads() {
    }

}
