package br.edu.unisep.carteira.controller;

import br.edu.unisep.carteira.publisher.DepositoEventPublisher;
import br.edu.unisep.carteira.publisher.SaqueEventPublisher;
import br.edu.unisep.carteira.publisher.TransferenciaEventPublisher;
import br.edu.unisep.carteira.exception.ResourceNotFoundException;
import br.edu.unisep.carteira.model.Transacao;
import br.edu.unisep.carteira.model.Usuario;
import br.edu.unisep.carteira.repository.TransacaoRepository;
import br.edu.unisep.carteira.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class TransacaoController {

    //TODO Atualizado em
    //TODO pegar usuario da sessão

    @Autowired
    private TransacaoRepository transacaoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private DepositoEventPublisher depositoEventPublisher;

    @Autowired
    private SaqueEventPublisher saqueEventPublisher;

    @Autowired
    private TransferenciaEventPublisher transferenciaEventPublisher;

    @GetMapping("/transacoes/{id}")
    public List<Transacao> getAllTransacoes(@PathVariable(value = "id") Long id)
        throws ResourceNotFoundException {
            Usuario usuario = usuarioRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Usuário não encontrado :: " + id));

        return usuario.getTransacoes();
    }

    @PostMapping("/transacoes/deposito/{id}")
    public Transacao deposito(@PathVariable(value = "id") Long id,
                              @RequestBody Transacao transacao)
        throws ResourceNotFoundException {
            Usuario usuario = usuarioRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Usuário não encontrado :: " + id));

        transacao.setUsuario(usuario);
        transacao.setData(new Date());

        if (transacao.getDescricao() == null) {
            transacao.setDescricao("Depósito de R$" + transacao.getValor() + " para " + usuario.getNome());
        }

        transacao.setUsuario(usuario);

        Transacao newTransacao = transacaoRepository.save(transacao);

        //TODO Evento não vai se transação falhar
        depositoEventPublisher.publishEvent(newTransacao);

        return newTransacao;
    }

    @PostMapping("/transacoes/saque/{id}")
    public Transacao saque(@PathVariable(value = "id") Long id,
                          @RequestBody Transacao transacao)
        throws ResourceNotFoundException {
            Usuario usuario = usuarioRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Usuário não encontrado :: " + id));

        transacao.setUsuario(usuario);
        transacao.setData(new Date());

        if (transacao.getDescricao() == null) {
            transacao.setDescricao("Saque de R$" + transacao.getValor() + " para " + usuario.getNome());
        }

        transacao.setUsuario(usuario);

        if (usuario.getCarteira().getSaldo() - transacao.getValor() < 0) {
            throw new ResourceNotFoundException("Saldo insuficiente");
        }

        Transacao newTransacao = transacaoRepository.save(transacao);

        //TODO Evento não vai se transação falhar
        saqueEventPublisher.publishEvent(newTransacao);

        return newTransacao;
    }

    @PostMapping("/transacoes/transferencia/{id}")
    public Transacao transferencia(@PathVariable(value = "id") Long id,
                                   @RequestBody Transacao transacao)
        throws ResourceNotFoundException {
            Usuario remetente = usuarioRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Usuário não encontrado :: " + id));
            Usuario destinatario = usuarioRepository.findById(transacao.getUsuario().getId()).orElseThrow(() ->
                new ResourceNotFoundException("Usuário não encontrado :: " + transacao.getUsuario().getId()));

        transacao.setData(new Date());

        if (transacao.getDescricao() == null) {
            transacao.setDescricao("Transferência de R$" +
                                    transacao.getValor() + " para " +
                                    remetente.getNome() + " de " +
                                    destinatario.getNome());
        }

        transacao.setUsuario(destinatario);

        Transacao newTransacao = transacaoRepository.save(transacao);

        //TODO Evento não vai se transação falhar
        transferenciaEventPublisher.publishEvent(newTransacao);

        return newTransacao;
    }
}
