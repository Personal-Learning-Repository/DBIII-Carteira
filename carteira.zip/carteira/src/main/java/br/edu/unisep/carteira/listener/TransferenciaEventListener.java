package br.edu.unisep.carteira.listener;

import br.edu.unisep.carteira.publisher.DepositoEventPublisher;
import br.edu.unisep.carteira.publisher.SaqueEventPublisher;
import br.edu.unisep.carteira.event.TransferenciaEvent;
import br.edu.unisep.carteira.model.Transacao;
import br.edu.unisep.carteira.repository.CarteiraRepository;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class TransferenciaEventListener implements ApplicationListener<TransferenciaEvent> {

    private final CarteiraRepository carteiraRepository;
    private final DepositoEventPublisher depositoEventPublisher;
    private final SaqueEventPublisher saqueEventPublisher;

    public TransferenciaEventListener(CarteiraRepository carteiraRepository,
                                      DepositoEventPublisher depositoEventPublisher,
                                      SaqueEventPublisher saqueEventPublisher) {
        this.carteiraRepository = carteiraRepository;
        this.depositoEventPublisher = depositoEventPublisher;
        this.saqueEventPublisher = saqueEventPublisher;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onApplicationEvent(TransferenciaEvent event) {
        Transacao transacaoRemetente = event.getTransacao();
        Transacao transacaoDestinatario = new Transacao();

        depositoEventPublisher.publishEvent(transacaoDestinatario);
        saqueEventPublisher.publishEvent(transacaoRemetente);

        transacaoDestinatario.setValor(transacaoRemetente.getValor());
        transacaoDestinatario.setUsuario(transacaoRemetente.getUsuario());
        transacaoDestinatario.setData(transacaoRemetente.getData());

        //TODO Descricao

//        if (transacaoRemetente.getDescricao() == null) {
//            transacaoRemetente.setDescricao("Transferência de R$" +
//                                            transacaoRemetente.getValor() + " para " +
//                                            transacaoRemetente.getNome() + " de " +
//                                            transacaoDestinatario.getNome()
//            );
//        }

        transacaoDestinatario.setValor(transacaoRemetente.getValor());
    }
}
