package br.edu.unisep.carteira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarteiraApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarteiraApplication.class, args);
    }

}
