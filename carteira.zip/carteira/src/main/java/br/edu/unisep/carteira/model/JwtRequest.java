package br.edu.unisep.carteira.model;

public class JwtRequest {
}
